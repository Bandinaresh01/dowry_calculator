# dowry
Analyze dowry practices with a dataset capturing socio-economic and cultural factors, including age, education, income, family wealth, location, and dowry amounts. This repository provides insights into societal patterns and aids discussions on addressing dowry-related issues.
